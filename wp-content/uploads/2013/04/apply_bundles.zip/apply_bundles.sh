#!/bin/sh
STATUS=0
SCRIPT_DIR="/opt/dell/toolkit/systems/drm_files/repository/"
PAYLOAD_DIR="/bundleapplicationlogs/"
SCRIPT_STATUS=0
cd /
mkdir "$PAYLOAD_DIR"
chmod -Rf 777 "$PAYLOAD_DIR"
cd "$SCRIPT_DIR"

## Check for supported system, if the system is supported by this Deployment Media
## then, apply the components directly. Otherwise, a user shall select from a menu

# preset matched bundle location
MATCHEDBUNDLE=""
# execute check sysid script if the script is found
if [ -f "/opt/dell/toolkit/systems/drm_files/reserved/checksysid.sh" ]
then
	. "/opt/dell/toolkit/systems/drm_files/reserved/checksysid.sh"
fi

if [ "$MATCHEDBUNDLE" != "" ]
then
	cd "$SCRIPT_DIR""$MATCHEDBUNDLE"
else
	DIR_ARRAY_LENGTH=0
	echo "Please select a bundle to deploy on this system"
	echo ""

	find ./* -type d  > "$PAYLOAD_DIR"tempDirList.tmp

	while read file;
	do
		echo `expr $DIR_ARRAY_LENGTH + 1`". ""${file:2}"
		DIR_ARRAY[${#DIR_ARRAY[*]}]="${file:2}"
		DIR_ARRAY_LENGTH="${#DIR_ARRAY[*]}"
	done < "$PAYLOAD_DIR"tempDirList.tmp

	for i in ${!DIR_ARRAY[*]}
	do
		VALID_INPUT_ARRAY[i]=`expr $i + 1`
	done

	echo ""
	SELECTION_INDEX=-1
	MAX_VALID_INDEX=`expr $DIR_ARRAY_LENGTH - 1`


	while [  "$SELECTION_INDEX" -lt 0 ] || [ "$SELECTION_INDEX" -gt "$MAX_VALID_INDEX" ]
	do
		#if [ "$MAX_VALID_INDEX" -eq 0 ]
		#then
		#	SELECTION_INDEX=1
		#else
			echo ""
			echo "Input the number corresponding to the bundle you would like to apply to this system followed by <ENTER>"
			read SELECTION_INDEX
		#fi
		
		#validate selection index
		VALID=false
		for INDEX in ${VALID_INPUT_ARRAY[*]}
		do
			
			if [ "$INDEX" == "$SELECTION_INDEX" ]
			then
				VALID=true
				break
			fi
		done

		if [ $VALID == true ]
		then
			SELECTION_INDEX=`expr $SELECTION_INDEX - 1`	
		else
			SELECTION_INDEX=-1
		fi
	done


	# change directory to a bundle folder, then execute all .sh files from there
	cd "$SCRIPT_DIR""${DIR_ARRAY[SELECTION_INDEX]}"
fi 

for i in `ls *.sh`
do
	echo "executing script $i"
	ERROR_STRING=`"./${i}"`
	if [ "$?" != 0 ]
	then
		STATUS=1
		break
	fi
	echo "$ERROR_STRING"
done

if [ -f "$PAYLOAD_DIR"tempDirList.tmp ]
then
	rm "$PAYLOAD_DIR"tempDirList.tmp
fi

# run custom scripts
cd $(dirname $0)

for i in `ls *.sh`
do
	if [ "$i" != "$(basename $0)" ]
	then
		echo "executing user's custom script: $i"
		ERROR_STRING=`"./${i}"`
		if [ "$?" != 0 ]
		then
			STATUS=1
			break
		fi
		echo "$ERROR_STRING"
	fi
done

exit "$STATUS"